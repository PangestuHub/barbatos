<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Session;
use Hash;

class RegistrationController extends Controller
{
    public function login()
    {
        return view('registration.login');
    }

    public function register()
    {
        return view('registration.register');
    }

    public function postlogin(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            return redirect()->intended('homepage')
                        ->withSuccess('You have Successfully loggedin');
        }

        return redirect("login")->withSuccess('Oppes! You have entered invalid credentials');
    }

    public function postRegistration(Request $request)
    {
        /* validasi ga yakin bener*/
        $request->validate([
            'name' => 'required|min:5',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8',
            'confirm password' => 'required|same:password',
            'gender' => 'required',
            'date of birth' => 'required',
            'country' => 'required',
        ]);

        $data = $request->all();
        $check = $this->create($data);

        return redirect("homepage")->withSuccess('Great! You have Successfully logged in');
    }


    /*public function index()
    {
        return view('registration.login');
    }
    */
}


